"""initial

Revision ID: b159ee510a90
Revises: 
Create Date: 2023-08-13 17:18:17.499346

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'b159ee510a90'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
